﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Sprint0
{
    /*
     * This is the a concrete class for a keyboard sprite controller
     * 
     * Dictionary:
     * "D1" -------- Non-moving non-animated sprite
     * "D2" -------- Non-moving animated sprite
     * "D3" -------- Moving non-animated sprite
     * "D4" -------- Moving animated sprite 
     * "D0" -------- Quit the program
     */

    class SpriteSettingController : IController
    {

        private SpriteBatch SpriteBatch;
        private NonMovingAnimatedSprite NonMovingAnimatedSprite;
        private NonMovingNonAnimatedSprite NonMovingNonAnimatedSprite;
        private MovingNonAnimatedSprite MovingNonAnimatedSprite;
        private MovingAnimatedSprite MovingAnimatedSprite;
        private KeyboardState oldState;
        private KeyboardState newState;


        public SpriteSettingController(NonMovingAnimatedSprite nonMovingAnimatedSprite, NonMovingNonAnimatedSprite nonMovingNonAnimatedSprite, 
            MovingNonAnimatedSprite movingNonAnimatedSprite, MovingAnimatedSprite movingAnimatedSprite, SpriteBatch spriteBatch)
        {
            NonMovingAnimatedSprite = nonMovingAnimatedSprite;
            NonMovingNonAnimatedSprite = nonMovingNonAnimatedSprite;
            MovingNonAnimatedSprite = movingNonAnimatedSprite;
            MovingAnimatedSprite = movingAnimatedSprite;
            SpriteBatch = spriteBatch;
           
            
        }

        /*
         * Update will display corresponding sprites to the screen based on the key is currently pushing.
         */
        public void Update()
        {
            
            oldState = newState;
            newState = Keyboard.GetState();

            
            if (oldState.IsKeyUp(Keys.D1) && newState.IsKeyDown(Keys.D1)) 
            {
                NonMovingNonAnimatedSprite.Draw(SpriteBatch);
            }
            else if (oldState.IsKeyUp(Keys.D2) && newState.IsKeyDown(Keys.D2))
            {
                NonMovingAnimatedSprite.Draw(SpriteBatch);
            }
            else if (oldState.IsKeyUp(Keys.D3) && newState.IsKeyDown(Keys.D3))
            {
                MovingNonAnimatedSprite.Draw(SpriteBatch);
            }
            else if (oldState.IsKeyUp(Keys.D4) && newState.IsKeyDown(Keys.D4))
            {
                MovingAnimatedSprite.Draw(SpriteBatch);
            }
            




        }
    }
}
