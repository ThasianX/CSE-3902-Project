﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Sprint0
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;
        private NonMovingAnimatedSprite nonMovingAnimatedSprite;
        private NonMovingNonAnimatedSprite nonMovingNonAnimatedSprite;
        private MovingNonAnimatedSprite movingNonAnimatedSprite;
        private MovingAnimatedSprite movingAnimatedSprite;
        private TextSprite textSprite;
        private SpriteFont font;
        private SpriteSettingController keyboardController;
        private MouseController mouseController;
        private QuittingController quitController;
        public static Game1 self;



        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
            self = this;
            


        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here


            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here

            // This block of code add the non-moving animated sprite to the screen
            Texture2D motionImage = Content.Load<Texture2D>("SpriteSheet of Mario/Animated");
            nonMovingAnimatedSprite = new NonMovingAnimatedSprite(motionImage, 1, 3);

            //This block of code add the non-moving non-animated sprite to the screen
            Texture2D image = Content.Load<Texture2D>("SpriteSheet of Mario/NonAnimated");
            nonMovingNonAnimatedSprite = new NonMovingNonAnimatedSprite(image);

            //This block of code add the moving non-animated sprite to the screen
            movingNonAnimatedSprite = new MovingNonAnimatedSprite(image);

            //This block of code add the moving animated sprite to the screen
            movingAnimatedSprite = new MovingAnimatedSprite(motionImage, 1, 3);

            // This block of code add the credits and my name to the screen
            font = Content.Load<SpriteFont>("font");
            textSprite = new TextSprite(font);



        }

        protected override void Update(GameTime gameTime)
        {
            // This controller control whether to quit the program
            quitController = new QuittingController(self);
            quitController.Update();
            
            // TODO: Add your update logic here

            // This update the non-moving animated sprite
            nonMovingAnimatedSprite.Update();

            // This update the moving non-animated sprite
            movingNonAnimatedSprite.Update();

            // This update the moving animated sprite
            movingAnimatedSprite.Update();

            


            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here

            // This support the user keyboard input to choose the sprite to show
            keyboardController = new SpriteSettingController(nonMovingAnimatedSprite, nonMovingNonAnimatedSprite,
                movingNonAnimatedSprite, movingAnimatedSprite, spriteBatch);
            keyboardController.Update();

            // This support the user mouse input to choose the sprite to show
            mouseController = new MouseController(nonMovingAnimatedSprite, nonMovingNonAnimatedSprite,
                movingNonAnimatedSprite, movingAnimatedSprite, spriteBatch);
            mouseController.Update();

            // This draws the credits
            textSprite.Draw(spriteBatch);

            base.Draw(gameTime);
        }
    }
}
