﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace Sprint0
{
    /*
     * This is the concrete class for moving non-animated sprite.
     */

    class MovingNonAnimatedSprite : ISprite
    {

        public Texture2D Texture { get; set; }
        private int Y; // This is for position
        private int SpriteSpeed; // This is for speed 

        public MovingNonAnimatedSprite(Texture2D texture)
        {
            Texture = texture;
            SpriteSpeed = 10;
         
        }



        public void Update()
        {
            Y -= SpriteSpeed;

            if(Y <= 0) // The sprite hits the top of the screen 
            {
                Y = 460; // transport the sprite to the bottom of the screen
            }

            
        }

        public void Draw(SpriteBatch spriteBatch)
        {

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, new Vector2(400, Y), Color.White);
            spriteBatch.End();

        }
    }
}