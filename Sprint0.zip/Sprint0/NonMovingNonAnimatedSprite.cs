﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace Sprint0
{
    /*
     * This is the concrete class for non-moving non-animated sprite.
     */

    class NonMovingNonAnimatedSprite : ISprite
    {

        public Texture2D Texture { get; set; }

        public NonMovingNonAnimatedSprite(Texture2D texture)
        {
            Texture = texture;
            
            
        }

        public void Update()
        {
            // Static non-animated image, no need to update.
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            
            spriteBatch.Begin();
            spriteBatch.Draw(Texture, new Vector2(400, 240), Color.White);
            spriteBatch.End();

        }
    }
}
