﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Sprint0
{
    /*
     * This is the concrete class for controller to quit the program. 
     * Press the key 0 will quit the game.
     */

    class QuittingController : IController
    {

        private KeyboardState KeyboardState;
        private MouseState MouseState;
        private Game1 Game1; // The game object.
        public QuittingController(Game1 game1)
        {
            KeyboardState = Keyboard.GetState();
            MouseState = Mouse.GetState();
            Game1 = game1;
        }
        public void Update()
        {
            if (KeyboardState.IsKeyDown(Keys.D0) || (MouseState.RightButton == ButtonState.Pressed))
            {
                Game1.Exit();
            }
        }
    }
}
