﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace Sprint0
{
    /*
     * This class is for static text sprite on the screen
     */

    class TextSprite : ISprite
    {
        public SpriteFont Font;

        public TextSprite(SpriteFont font)
        {
            Font = font;
        }

        public void Update()
        {
            // This is a static text sprite, no need to update.
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
            spriteBatch.DrawString(Font, "Credits", new Vector2(100, 100), Color.Black);
            spriteBatch.DrawString(Font, "Program Made By: Zheyuan Gao", new Vector2(100, 120), Color.Black);
            spriteBatch.DrawString(Font, "Sprites from: https://www.spriters-resource.com/nes/supermariobros/", new Vector2(100, 140), Color.Black);
            spriteBatch.End();
        }
    }
}
