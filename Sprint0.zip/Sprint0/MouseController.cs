﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace Sprint0
{
    /*
     * This class let the user can use mouse to choose sprites to display
     */
    class MouseController : IController
    {

        
        private SpriteBatch SpriteBatch;
        private NonMovingAnimatedSprite NonMovingAnimatedSprite;
        private NonMovingNonAnimatedSprite NonMovingNonAnimatedSprite;
        private MovingNonAnimatedSprite MovingNonAnimatedSprite;
        private MovingAnimatedSprite MovingAnimatedSprite;
        private MouseState oldState;
        private MouseState newState;

        public MouseController(NonMovingAnimatedSprite nonMovingAnimatedSprite, NonMovingNonAnimatedSprite nonMovingNonAnimatedSprite, 
            MovingNonAnimatedSprite movingNonAnimatedSprite, MovingAnimatedSprite movingAnimatedSprite, SpriteBatch spriteBatch)
        {
            NonMovingAnimatedSprite = nonMovingAnimatedSprite;
            NonMovingNonAnimatedSprite = nonMovingNonAnimatedSprite;
            MovingNonAnimatedSprite = movingNonAnimatedSprite;
            MovingAnimatedSprite = movingAnimatedSprite;
            SpriteBatch = spriteBatch;
        }

        /*
         * Update will display corresponding sprites to the screen based on the place the mouse is clicked.
         */
        public void Update()
        {
            newState = Mouse.GetState();


            if (newState.LeftButton == ButtonState.Pressed && oldState.LeftButton == ButtonState.Released 
                && newState.X < 400 && newState.Y <240)
            {
                // The mouse click the left up part of the screen
                NonMovingNonAnimatedSprite.Draw(SpriteBatch);
            }
            else if (newState.LeftButton == ButtonState.Pressed && oldState.LeftButton == ButtonState.Released
                && newState.X >= 400 && newState.Y < 240)
            {
                // The mouse click the right up part of the screen
                NonMovingAnimatedSprite.Draw(SpriteBatch);
            }
            else if (newState.LeftButton == ButtonState.Pressed && oldState.LeftButton == ButtonState.Released
                && newState.X < 400 && newState.Y >= 240)
            {
                // The mouse click the left bottom of the screen
                MovingNonAnimatedSprite.Draw(SpriteBatch);
            }
            else if (newState.LeftButton == ButtonState.Pressed && oldState.LeftButton == ButtonState.Released
                && newState.X >= 400 && newState.Y >= 240)
            {
                // The mouse click the right bottom of the screen 
                MovingAnimatedSprite.Draw(SpriteBatch);
            }
            
            oldState = newState;
        }
    }
}

